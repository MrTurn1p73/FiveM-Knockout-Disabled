fx_version 'cerulean'
game 'gta5'

author 'MrT'
description 'Disable Knockout System'
version '1.0.0'
lua54 'yes'

client_scripts {
    'knockout.lua'
}

-- if you have server-side stuff, you can also add:
-- server_scripts {
--     'server/knockout_server.lua'
-- }
