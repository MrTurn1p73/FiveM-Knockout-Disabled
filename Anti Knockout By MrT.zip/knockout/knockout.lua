while true do
    if GetPedStealthMovement(PlayerPedId()) then
        SetPedStealthMovement(PlayerPedId(), 0)
    end
    Wait(1) -- Capital W!
end
